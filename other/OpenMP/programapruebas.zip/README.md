# Programa de pruebas de OpenMP

En el este programa podemos probar el funcionamiento de OpenMP mediante el clásico problema de multiplicación de matrices. Concretamente, este programa multiplica una matriz por su traspuesta. Tras esto, obtenemos los resultados de la ejecución.

Para usar el programa disponemos de un archivo ```makefile``` con las siguientes opciones de uso:

```Makefile
make # Default: ejecuta make all

make all # Compila, ejecuta e imprime el resultado sobre un archivo y limpia los restos de la compilación

make compile # Compila

make save_in_a_file # Realiza la ejecución tumbando la salida sobre un archivo

make clear # Limpia el programa compilado
```

Tras esto, un breve ejemplo de ejecución:

```zsh
Trasteando con OpenMP - Jordi Sellés Enríquez
	Ejecución en sigle-core:
		Tiempo de ejecución: 2864.58 ms
	Ejecución en multi-core:
		Tiempo de ejecución: 628.326 ms
	Ganancia: 4.55907
```
