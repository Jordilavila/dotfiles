#include <omp.h>
#include <iostream>
#include <ctime>

#define N 1000
#define CHUNKSIZE 100
#define matSize 1000

double matO[matSize][matSize];
double matT[matSize][matSize];
double matR[matSize][matSize];

/**
 * @brief Esta función devuelve una marca de tiempo en el momento en la que la llamamos.
 * 
 * @return marca de tiempo.
 */
double seconds() {
    struct timespec now;
    clock_gettime(CLOCK_REALTIME, &now);
    return now.tv_sec + now.tv_nsec / 1000000000.0;
}

void rellenarMatrizSingle() {
    for(int i=0; i<matSize; i++)
        for(int j=0; j<matSize; j++)
            matO[i][j] = rand() % matSize;
}

void trasponerMatrizSingle() {
    for(int i=0; i<matSize; i++)
        for(int j=0; j<matSize; j++)
            matT[i][j] = matO[j][i];
}

void multiplicarMatrizSingle() {
    for(int i=0; i<matSize; i++)
        for(int j=0; j<matSize; j++)
            for(int k=0; k<matSize; k++)
                matR[i][j] += matT[i][k] * matO[k][j];
}

void rellenarMatrizMulti(int chunk) {
    int i, j;
    #pragma omp parallel shared(matO) private(i, j)
    {
        #pragma omp for schedule(auto) nowait
        for(i=0; i<matSize; i++)
            for(j=0; j<matSize; j++)
                matO[i][j] = rand() % matSize;
    }
}

void trasponerMatrizMulti(int chunk) {
    int i, j;
    #pragma omp parallel shared(matO, matT) private(i, j)
    {
        #pragma omp for schedule(auto) nowait
        for(i=0; i<matSize; i++)
            for(j=0; j<matSize; j++)
                matT[i][j] = matO[j][i];
    }
}

void multiplicarMatrizMulti(int chunk) {
    int i, j, k;
    #pragma omp parallel shared(matO, matT, matR) private(i, j, k)
    {
        #pragma omp for schedule(auto) nowait
        for(i=0; i<matSize; i++)
            for(j=0; j<matSize; j++)
                for(k=0; k<matSize; k++)
                    matR[i][j] += matT[i][k] * matO[k][j];
    }
}

int main(int argc, char *argv[]) {
    int chunk = CHUNKSIZE;
    srand(time(NULL));
    std::cout << "Trasteando con OpenMP - Jordi Sellés Enríquez" << std::endl;

    double time_single = seconds();
    rellenarMatrizSingle();
    trasponerMatrizSingle();
    multiplicarMatrizSingle();
    time_single = seconds() - time_single;
    time_single *= 1000;

    double time_paral = seconds();
    rellenarMatrizMulti(chunk);
    trasponerMatrizMulti(chunk);
    multiplicarMatrizMulti(chunk);
    time_paral = seconds() - time_paral;
    time_paral *= 1000;


    std::cout << "\tEjecución en sigle-core:" << std::endl;
    std::cout << "\t\tTiempo de ejecución: " << time_single << " ms" << std::endl;
    std::cout << "\tEjecución en multi-core:" << std::endl;
    std::cout << "\t\tTiempo de ejecución: " << time_paral << " ms" << std::endl;
    std::cout << "\tGanancia: " << time_single / time_paral << std::endl;
    return 0;
}